from setuptools import setup

setup(name='freemusicarchive',
      version='0.0.0',
      description='Free Music Archive',
      url='https://github.com/mdeff/fma',
      author='Michaël Defferrard',
      author_email='michael.defferrard@epfl.ch',
      license='MIT')
