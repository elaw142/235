from domainmodel.artist import Artist


class Track:
    pass
