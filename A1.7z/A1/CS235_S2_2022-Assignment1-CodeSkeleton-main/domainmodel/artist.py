class Artist:
    def __init__(self, artist_id: int, full_name: str):
        # TODO
        if not isinstance(full_name, str):
            self.__full_name = None
        else:
            self.__full_name = full_name.strip()

        if isinstance(artist_id, str) == True or artist_id < 0:
            raise ValueError
        else:
            self.__artist_id: int = artist_id
        pass

    @property
    def artist_id(self) -> int:
        return self.__artist_id

    @property
    def full_name(self) -> str:
        return self.__full_name

    @full_name.setter
    def full_name(self, new_full_name):
        # TODO
        if not isinstance(new_full_name, str):
            self.__full_name = None
        else:
            self.__full_name = new_full_name.strip()
        pass

    def __repr__(self):
        # we use access via the property here
        return f"<Artist {self.full_name}, artist id = {self.artist_id}>"

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        return self.artist_id == other.artist_id

    def __lt__(self, other):
        # TODO
        if not isinstance(other, self.__class__):
            return False
        return self.artist_id < other.artist_id
        pass

    def __hash__(self):
        # TODO
        return hash(self.artist_id)
        pass


artist1 = Artist(-5, 'Tailor Swift')
print(artist1)
artist2 = Artist(2, "Maroon 5")
print(artist2)
artist3 = Artist(3, 'Kate Bush')
print(artist3)
artist4 = Artist(4, ' Bad Bunny ')
print(artist4)
artist5 = Artist(5, 2910)
print(artist5.full_name)

print(artist1.__hash__)
print(artist1.__lt__("artist2"))
print(artist4.__eq__("oaiwhd"))